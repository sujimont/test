'''
movierulz deccandelight plugin
Copyright (C) 2016 gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''



from bs4 import BeautifulSoup, SoupStrainer
from resources.lib import client
from resources.lib.base import Scraper
from six.moves import urllib_parse

class dcine(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://mlsbd.shop/category/'
        self.icon = self.ipath + 'dcine.png'
        self.videos = []
        self.list = {
            '01Bollywood': self.bu + 'bollywood-movies/',
            '02Hindi Dubbed': self.bu + 'hindi-dubbed/',
            '03Punjabi': self.bu + 'punjabi/',
            '04Gujrati': self.bu,
            '99[COLOR yellow]** Search **[/COLOR]': self.bu[:-9] + '?s='
        }

    def get_menu(self):
        return (self.list, 7, self.icon)

    def get_items(self, url):
        movies = []

        # Handle search query
        if url.endswith('?s='):
            search_text = self.get_SearchQuery('Desi Cinemas')
            search_text = urllib_parse.quote_plus(search_text)
            url = url + search_text

        # Fetch HTML with error handling
        try:
            html = client.request(url)
            if not html:
                return ([], 8)
        except:
            return ([], 8)

        # Extract movie items
        try:
            soup = BeautifulSoup(html, "html.parser")
            posts = soup.find_all('div', class_='single-post')

            for post in posts:
                title = post.find('h2', class_='post-title').text.strip()
                post_url = post.find('a')['href']
                img_tag = post.find('img')
                thumb = img_tag['src'] if img_tag else None

                movies.append((title, thumb, post_url))
        except:
            pass

        # Handle pagination
        try:
            paginator_div = soup.find('div', class_='paginav text-center')
            next_page = paginator_div.find('a', class_='next page-numbers') if paginator_div else None
            if next_page:
                next_url = urllib_parse.urljoin(self.bu, next_page['href'])
                movies.append(('Next Page..', getattr(self, 'nicon', None), next_url))
        except:
            pass

        return (movies, 8)

    def get_videos(self, url):
        # Fetch intermediate URL with error handling
        try:
            html = client.request(url, headers=self.hdr)
            if not html:
                return []
        except:
            pass

        try:
            soup = BeautifulSoup(html, "html.parser")
            link = soup.find('a', class_='Dbtn watch')
            if not link:
                return []
            intermediate_url = link['href']

            # Fetch HTML from intermediate URL
            html = client.request(intermediate_url, headers=self.hdr)
            if not html:
                return []
        except:
            pass

        videos = []

        # Extract video links
        try:
            mlink = SoupStrainer('ul', {'class': 'px-4 py-6 list-none bg-gray-100 rounded-lg border'})
            videoclass = BeautifulSoup(html, "html.parser", parse_only=mlink)
            links = videoclass.find_all('a', class_='break-words')

            for link in links:
                vidurl = link.get('href')
                self.resolve_media(vidurl, videos)
        except:
            pass

        return videos
