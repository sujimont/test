from bs4 import BeautifulSoup, SoupStrainer
from resources.lib import client
from resources.lib.base import Scraper
from six.moves import urllib_parse
from xbmc import log
import re

class dcine(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://mydesi.cam/category/paid/'
        self.icon = self.ipath + 'dcine.png'
        self.videos = []
        self.list = {'01Bollywood': 'bollywood/',
                     '02Hindi Dubbed': 'hindi-dubbed/',
                     '03Punjabi': 'punjabi/',
                     '04Gujrati': 'https://mydesi.cam/category/paid/',
                     '99[COLOR yellow]** Search **[/COLOR]': self.bu[:-9] + '?s='}


    def get_menu(self):
        return (self.list, 7, self.icon)
        

    def get_items(self, url):
        movies = []
        if url[-3:] == '?s=':
            search_text = self.get_SearchQuery('Desi Cinemas')
            search_text = urllib_parse.quote_plus(search_text)
            url = url + search_text

        html = client.request(url)
        mlink = SoupStrainer('div', {'class': re.compile('^order-0')})
        mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
        # plink = SoupStrainer('nav')
        # Paginator = BeautifulSoup(html, "html.parser", parse_only=plink)
        items = mdiv.find_all('div', {'class': 'video-block'})

        for item in items:
            title = self.unescape(item.find('span', {'class': 'title'}).text)
            title = title.encode('utf8') if self.PY2 else title
            url = item.find('a', {'class': 'thumb'}).get('href')
            try:
                thumb = item.find('img', {'class': 'video-img'}).get('data-src')
            except:
                thumb = self.icon
            movies.append((title, thumb, url))

        # if 'next' in str(Paginator):
            # purl = Paginator.find('a', {'class': 'next'}).get('href')
            # currpg = Paginator.find('a', {'class': 'bg-primary'}).text
            # lastpg = Paginator.find_all('a', {'class': 'page-numbers'})[-2].text
            # title = 'Next Page.. (Currently in Page {0} of {1})'.format(currpg, lastpg)
            # movies.append((title, self.nicon, purl))

        return (movies, 8)

    # def get_videos(self, url):
        # videos = []
        # html = client.request(url)
        # #log("HTML Content: {}".format(html), level=xbmc.LOGDEBUG)  # Debug: Log the HTML content

        # meta_tags = re.findall('<meta itemprop="contentURL" content="([^"]+)"', html)
        # #log("Meta Tags Found: {}".format(meta_tags), level=xbmc.LOGDEBUG)  # Debug: Log the found meta tags

        # #for _ in meta_tags:
            # # Hardcoded video URL for testing purposes
            # video_url = 'https://mdn.mydesi.cam/wp-content/uploads/2025/01/mydesi-cam-259426-1.mp4'
            # #log("Video URL: {}".format(video_url), level=xbmc.LOGDEBUG)  # Debug: Log the video URL being added

            # # Add the video URL to the videos list
            # #videos.append({'source': video_url, 'quality': '720p', 'codec': 'h264'})

            # # Attempt to resolve the video URL directly
            # #self.resolve_media(video_url, videos)
        # vidhost = 'mydesi.cam'
        # videos.append((vidhost, video_url))

        # #log("Videos List: {}".format(videos), level=xbmc.LOGDEBUG)  # Debug: Log the final videos list
        # return videos

    def get_videos(self, url):
        videos = []

        video_url = 'https://mdn.mydesi.cam/wp-content/uploads/2025/01/mydesi-cam-259426-1.mp4'
        vidhost = 'mydesi.cam'
        videos.append((vidhost, video_url))
        
        return videos

        