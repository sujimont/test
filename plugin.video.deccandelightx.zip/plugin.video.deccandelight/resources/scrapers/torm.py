'''
DeccanDelight scraper plugin
Copyright (C) 2016 gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
'''
from bs4 import BeautifulSoup, SoupStrainer
from resources.lib import client
from resources.lib.base import Scraper


class torm(Scraper):
    def __init__(self):
        Scraper.__init__(self)
        self.bu = 'https://tormalayalam.vip/'
        self.icon = self.ipath + 'torm.png'
        self.list = {'01Movies': self.bu}

    def get_menu(self):
        return (self.list, 7, self.icon)

    def get_items(self, url):
        movies = []

        html = client.request(url)
        mlink = SoupStrainer('div', {'class': 'Content'})
        mdiv = BeautifulSoup(html, "html.parser", parse_only=mlink)
        plink = SoupStrainer('nav', {'class': 'navigation pagination'})
        paginator = BeautifulSoup(html, "html.parser", parse_only=plink)
        items = mdiv.find_all('article', {'class': 'TPost C'})  # Updated selector for articles

        for item in items:
            title = item.find('h2', {'class': 'Title'}).text.strip()
            url = item.find('a')['href']
            thumb = item.find('img').get('src') or item.find('img').get('data-lazy-src')
            movies.append((title, thumb, url))

        try:
            next_page = paginator.find('a', {'class': 'next page-numbers'})['href']
            if next_page:
                title = 'Next Page..'
                movies.append((title, self.nicon, next_page))
        except:
            pass

        return (movies, 8)

    # def get_videos(self, url):
        # videos = []

        # html = client.request(url)
        # mlink = SoupStrainer('div', {'class': 'video_player'})
        # videoclass = BeautifulSoup(html, "html.parser", parse_only=mlink)

        # try:
            # links = videoclass.find_all('iframe')
            # for link in links:
                # vidurl = link.get('data-url')
                # self.resolve_media(vidurl, videos)
        # except:
            # pass

        # return videos






    
    
    def get_videos(self, url):
        videos = []

        html = client.request(url)
        mlink = SoupStrainer('div', {'class': 'TPlayer'})
        videoclass = BeautifulSoup(html, "html.parser", parse_only=mlink)

        try:
            # Find the <a> tag with id "playback" and get the data-url attribute
            playback_link = videoclass.find('a', {'id': 'playback'})
            if playback_link and 'data-url' in playback_link.attrs:
                vidurl = playback_link['data-url']
                self.resolve_media(vidurl, videos)
        except:
            pass

        return videos

    


